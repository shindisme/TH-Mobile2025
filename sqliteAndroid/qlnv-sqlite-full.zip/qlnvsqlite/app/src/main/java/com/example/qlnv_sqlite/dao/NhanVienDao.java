package com.example.qlnv_sqlite.dao;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.qlnv_sqlite.model.NhanVien;

import java.util.ArrayList;
import java.util.List;

public class NhanVienDao {
    private final DbHelper dbHelper;

    public NhanVienDao(DbHelper dbHelper) {
        this.dbHelper = dbHelper;
    }

    public List<NhanVien> getAll() {
        List<NhanVien> dsnv = new ArrayList<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor c = db.query(
                "nhanvien",
                null,
                null,
                null,
                null,
                null,
                null
        );
        while (c.moveToNext()) {
            dsnv.add(new NhanVien(
                    c.getString(c.getColumnIndexOrThrow("ma")),
                    c.getString(c.getColumnIndexOrThrow("ten")),
                    c.getString(c.getColumnIndexOrThrow("sdt"))
            ));
        }
        c.close();
        return dsnv;
    }

    public boolean them(NhanVien nv) {
        ContentValues values = new ContentValues();
        values.put("ma", nv.getMa());
        values.put("ten", nv.getTen());
        values.put("sdt", nv.getSdt());

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.insert("nhanvien", null, values);

        return true;
    }

    public boolean xoa(String ma) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        String[] args = {ma};
        int rows = db.delete("nhanvien", "ma = ?", args);
        return rows > 0;
    }

    public boolean sua(NhanVien nv) {
        ContentValues values = new ContentValues();
        values.put("ten", nv.getTen());
        values.put("sdt", nv.getSdt());

        String[] args = {nv.getMa()};
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        int rows = db.update("nhanvien", values, "ma = ?", args);
        return rows > 0;
    }

}
