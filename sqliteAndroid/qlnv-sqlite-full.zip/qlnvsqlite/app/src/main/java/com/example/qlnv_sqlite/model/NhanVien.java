package com.example.qlnv_sqlite.model;

import java.io.Serializable;

public class NhanVien implements Serializable {
    private String ma, ten, sdt;

    @Override
    public String toString() {
        return "Ma: " + ma + "\nTen: " + ten + "\nSdt: " + sdt;
    }

    public String getMa() {
        return ma;
    }

    public void setMa(String ma) {
        this.ma = ma;
    }

    public String getTen() {
        return ten;
    }

    public void setTen(String ten) {
        this.ten = ten;
    }

    public String getSdt() {
        return sdt;
    }

    public void setSdt(String sdt) {
        this.sdt = sdt;
    }

    public NhanVien() {
    }

    public NhanVien(String ma, String ten, String sdt) {
        this.ma = ma;
        this.ten = ten;
        this.sdt = sdt;
    }
}
