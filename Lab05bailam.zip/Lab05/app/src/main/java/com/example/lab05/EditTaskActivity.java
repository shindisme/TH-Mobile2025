package com.example.lab05;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.TimePicker;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.lab05.model.Task;
import com.example.lab05.util.FormatUtil;

import java.util.Calendar;

public class EditTaskActivity extends AppCompatActivity {
    EditText edtName;
    TextView tvTime, tvDate;
    ImageButton ibtnTime, ibtnDate;
    Button btnSave;
    Calendar calendar;
    Task task;
    int resultCode = 11;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_edit_task);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // add controls
        edtName = findViewById(R.id.edtName);
        tvDate = findViewById(R.id.tvDate);
        tvTime = findViewById(R.id.tvTime);
        ibtnDate = findViewById(R.id.ibtnDate);
        ibtnTime = findViewById(R.id.ibtnTime);
        btnSave = findViewById(R.id.btnSave);
        task = null;
        calendar = Calendar.getInstance();

        /* get data */


        /* add events */
        addEvents();
    }

    private void addEvents() {
        btnSave.setOnClickListener(view -> {
            if (task == null) {
                task = new Task();
            }
            task.setName(edtName.getText().toString());
            task.setDate(calendar.getTime());
            Intent intent = getIntent();
            intent.putExtra("TRA", task);
            setResult(resultCode, intent);
            finish();
        });
        ibtnTime.setOnClickListener(view -> {
            TimePickerDialog.OnTimeSetListener listener = new TimePickerDialog.OnTimeSetListener() {
                @Override
                public void onTimeSet(TimePicker timePicker, int i, int i1) {
                    calendar.set(Calendar.HOUR_OF_DAY, i);
                    calendar.set(Calendar.MINUTE, i1);
                    tvTime.setText(FormatUtil.formatime(calendar.getTime()));
                }
            };
            TimePickerDialog timePickerDialog = new TimePickerDialog(EditTaskActivity.this, listener,
                    calendar.get(Calendar.HOUR_OF_DAY),
                    calendar.get(Calendar.MINUTE), false);
            timePickerDialog.show();
        });
        ibtnDate.setOnClickListener(view -> {
            DatePickerDialog.OnDateSetListener listener = new DatePickerDialog.OnDateSetListener() {
                @Override
                public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                    calendar.set(Calendar.YEAR, i);
                    calendar.set(Calendar.MONTH, i1);
                    calendar.set(Calendar.DATE, i2);
                    tvDate.setText(FormatUtil.formatDate(calendar.getTime()));
                }
            };

            DatePickerDialog datePickerDialog = new DatePickerDialog(
                    EditTaskActivity.this,
                    listener,
                    calendar.get(Calendar.YEAR),
                    calendar.get(Calendar.MONTH),
                    calendar.get(Calendar.DATE)
            );
            datePickerDialog.show();
        });
    }

    private void resetView() {
        edtName.setText("");
        tvDate.setText("dd/MM/yyyy");
        tvTime.setText("hh:mm aa");
        calendar = Calendar.getInstance();
        task = null;
    }
}