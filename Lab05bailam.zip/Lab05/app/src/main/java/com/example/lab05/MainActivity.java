package com.example.lab05;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.lab05.model.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class MainActivity extends AppCompatActivity {
    ListView lvTask;
    FloatingActionButton fabAdd;
    ArrayAdapter<Task> adapter;
    Task task;
    int pos = -1;
    int requestCode = 12, resultCode = 11;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        fabAdd = findViewById(R.id.fabAdd);
        lvTask = findViewById(R.id.lvTask);
        adapter = new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_list_item_1);
        lvTask.setAdapter(adapter);
        task = null;

//        add events
        addEvent();
    }

    private void addEvent() {
        fabAdd.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, EditTaskActivity.class);
            startActivityForResult(intent, requestCode);
        });

        lvTask.setOnItemLongClickListener((adapterView, view, i, l) -> {

            return true;
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == this.requestCode) {
            if (resultCode == this.resultCode) {
                if (data.hasExtra("TRA")) {
                    Task tra = (Task) data.getSerializableExtra("TRA");
                    if (task == null) {
                        adapter.add(tra);
                    } else {
                        task.setName(tra.getName());
                        task.setDate(tra.getDate());
                    }
                    adapter.notifyDataSetChanged();
                }
            }
        }
        task = null;
    }

   
}